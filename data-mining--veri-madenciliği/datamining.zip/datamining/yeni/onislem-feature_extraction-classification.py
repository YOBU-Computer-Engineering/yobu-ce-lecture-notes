#!/usr/bin/env python
# coding: utf-8

# In[109]:


import pandas as pd


# In[110]:


yazi="""What is your name? @https: name
My name is Omer
Here is my old car. @https: car
My favorite football team is Besiktas #football
The 5 orange balls #color
Who is the man in the red car?"""


# In[111]:


yazi


# In[112]:


satir=yazi.split()


# In[113]:


satir


# In[114]:


satir=yazi.split("\n")


# In[115]:


satir


# In[116]:


seri=pd.Series(satir)


# In[117]:


seri


# In[118]:


df=pd.DataFrame(seri, columns=["degerler"])


# In[119]:


df


# In[120]:


df["degerler1"]=df["degerler"].apply(lambda x:x.lower())


# In[121]:


df["degerler1"]=df["degerler"].str.lower()


# In[122]:


df


# In[123]:


df["degerler1"]=df["degerler1"].apply(lambda x: ' '.join([word for word in x.split() if not word.startswith('#')]))


# In[124]:


df["degerler1"]=df["degerler1"].apply(lambda x: ' '.join([word for word in x.split() if not word.startswith('@')]))


# In[125]:


df["degerler2"]=df["degerler1"].str.replace('[^\w\s]','',regex=True)


# In[126]:


df


# In[127]:


df["degerler3"]=df["degerler2"].str.replace('\d+','',regex=True)


# In[128]:


df


# In[129]:


import nltk


# In[130]:


nltk.download('stopwords')


# In[131]:


from nltk.corpus import stopwords


# In[132]:


stop_words=stopwords.words('english')


# In[133]:


stop_words


# In[134]:


df["degerler4"]=df["degerler3"].apply(lambda x: ' '.join([word for word in x.split() if word not in (stop_words)]))


# In[135]:


df


# In[136]:


df["degerler4"]


# In[137]:


from sklearn.feature_extraction.text import TfidfVectorizer
 


# In[138]:


liste=["degerler","degerler1","degerler2","degerler3"]


# In[139]:


df.drop(liste,axis=1,inplace=True)


# In[140]:


df


# In[141]:


tfidf=TfidfVectorizer()


# In[142]:


data=tfidf.fit_transform(df["degerler4"])


# In[143]:


data


# In[144]:


data=data.toarray()


# In[145]:


sutun=tfidf.get_feature_names()


# In[146]:


sutun


# In[147]:


dataf=pd.DataFrame(data,columns=sutun)


# In[148]:


dataf


# In[149]:


dataf["y"]=[1,0,0,1,0,0]


# In[150]:


dataf


# In[151]:


from sklearn.model_selection import train_test_split


# In[152]:


inputs=["balls","besiktas","car","favorite","football","man","name","old","omer","orange","red","team"]


# In[153]:


X_train,X_test,y_train, y_test=train_test_split(dataf[inputs],dataf["y"],test_size=0.2)


# In[154]:


X_train,X_test,y_train, y_test=train_test_split(dataf[dataf.columns[0:12]],dataf["y"],test_size=0.2)


# In[155]:


X_train


# In[156]:


y_train


# In[157]:


from sklearn.neighbors import KNeighborsClassifier


# In[158]:


knn=KNeighborsClassifier(n_neighbors=3)


# In[159]:


knn.fit(X_train,y_train)


# In[160]:


tahmin=knn.predict(X_test)


# In[161]:


tahmin


# In[162]:


y_test


# In[163]:


from sklearn.metrics import accuracy_score


# In[164]:


print(accuracy_score(tahmin,y_test))


# In[165]:


tp=true positive 1 olan değeri doğru bilmek
tn=true negative 0 olan değeri doğru bilmek
fp=false positive 1 olan değeri yanlış bilmek
fn=false negative 0 olan değeri yanlış bilmek,


# In[166]:


from sklearn.metrics import confusion_matrix


# In[171]:


tn,fp,fn,tp=confusion_matrix(y_test,tahmin).ravel()


# In[172]:


tn,fp,fn,tp


# In[169]:


y_test


# In[170]:


tahmin


# In[ ]:




