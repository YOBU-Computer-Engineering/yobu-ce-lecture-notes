#!/usr/bin/env python
# coding: utf-8

# In[34]:


import pandas as pd
from gensim.models import Word2Vec


# In[2]:


yazi="""What is your name? @https: name
My name is Omer
Here is my old car. @https: car
My favorite football team is Besiktas #football
The 5 orange balls #color
Who is the man in the red car?"""


# In[3]:


yazi


# In[4]:


satir=yazi.split()


# In[5]:


satir


# In[6]:


satir=yazi.split("\n")


# In[7]:


satir


# In[8]:


seri=pd.Series(satir)


# In[9]:


seri


# In[10]:


df=pd.DataFrame(seri, columns=["degerler"])


# In[11]:


df


# In[12]:


df["degerler1"]=df["degerler"].apply(lambda x:x.lower())


# In[13]:


df["degerler1"]=df["degerler"].str.lower()


# In[14]:


df


# In[15]:


df["degerler1"]=df["degerler1"].apply(lambda x: ' '.join([word for word in x.split() if not word.startswith('#')]))


# In[16]:


df["degerler1"]=df["degerler1"].apply(lambda x: ' '.join([word for word in x.split() if not word.startswith('@')]))


# In[17]:


df["degerler2"]=df["degerler1"].str.replace('[^\w\s]','',regex=True)


# In[18]:


df


# In[19]:


df["degerler3"]=df["degerler2"].str.replace('\d+','',regex=True)


# In[20]:


df


# In[21]:


import nltk


# In[22]:


nltk.download('stopwords')


# In[23]:


from nltk.corpus import stopwords


# In[24]:


stop_words=stopwords.words('english')


# In[25]:


stop_words


# In[26]:


df["degerler4"]=df["degerler3"].apply(lambda x: ' '.join([word for word in x.split() if word not in (stop_words)]))


# In[27]:


df


# In[28]:


df["degerler4"]


# In[29]:


from sklearn.feature_extraction.text import TfidfVectorizer
 


# In[30]:


liste=["degerler","degerler1","degerler2","degerler3"]


# In[31]:


df.drop(liste,axis=1,inplace=True)


# In[32]:


df


# In[37]:


model=Word2Vec(df["degerler4"].str.split(), min_count=1, window=3,sg=1) 


# In[39]:


model.wv["car"]


# In[40]:


model.wv.most_similar('car')


# In[41]:


model.wv.most_similar('orange')


# In[43]:


model.wv.index_to_key


# In[57]:


model.wv["omer"]


# In[46]:


model.wv.get_vector("car")


# In[53]:


model.wv.vectors


# In[55]:


model.wv.vectors


# In[58]:


model.wv.vectors[11]


# In[59]:


model.wv.vectors.T


# In[60]:


veri=pd.DataFrame(model.wv.vectors.T,columns=[model.wv.index_to_key])


# In[61]:


veri


# In[81]:


docs_vectors = pd.DataFrame()
for doc in df['degerler4']:
    temp = pd.DataFrame()
    for word in doc.split(' '):
        word_vec = model.wv[word]
        temp = temp.append(pd.Series(word_vec), ignore_index = True)
    print(temp)
    doc_vector = temp.mean() 
    docs_vectors = docs_vectors.append(pd.Series(doc_vector), ignore_index = True)


# In[79]:


docs_vectors


# In[82]:


df["degerler4"]


# In[84]:


docs_vectors["y"]=[1,0,0,1,0,0]


# In[85]:


docs_vectors


# In[ ]:




