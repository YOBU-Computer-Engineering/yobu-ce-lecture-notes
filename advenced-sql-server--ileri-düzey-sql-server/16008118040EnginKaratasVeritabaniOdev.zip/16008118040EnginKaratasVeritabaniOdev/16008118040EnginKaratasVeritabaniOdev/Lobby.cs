﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _16008118040EnginKaratasVeritabaniOdev
{
    public partial class Lobby : Form
    {
        public Lobby()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("test");
            SqlConnection baglanti = new SqlConnection("Data Source=.;Initial Catalog=UrunSatis;Integrated Security=True");
            SqlCommand sqlcmd = new SqlCommand("sp_t_select_personel", baglanti);
            sqlcmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dr = new SqlDataAdapter(sqlcmd);
            DataSet ds = new DataSet();
            dr.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection baglanti = new SqlConnection("Data Source=.;Initial Catalog=UrunSatis;Integrated Security=True");
            SqlCommand sqlcmd = new SqlCommand("sp_t_select_adres", baglanti);
            sqlcmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dr = new SqlDataAdapter(sqlcmd);
            DataSet ds = new DataSet();
            dr.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection baglanti = new SqlConnection("Data Source=.;Initial Catalog=UrunSatis;Integrated Security=True");
            SqlCommand sqlcmd = new SqlCommand("sp_t_select_bolge", baglanti);
            sqlcmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dr = new SqlDataAdapter(sqlcmd);
            DataSet ds = new DataSet();
            dr.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SqlConnection baglanti = new SqlConnection("Data Source=.;Initial Catalog=UrunSatis;Integrated Security=True");
            SqlCommand sqlcmd = new SqlCommand("sp_t_select_personel_tipi", baglanti);
            sqlcmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dr = new SqlDataAdapter(sqlcmd);
            DataSet ds = new DataSet();
            dr.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void DisplayData()
        {
            SqlConnection baglanti = new SqlConnection("Data Source=.;Initial Catalog=UrunSatis;Integrated Security=True");
            SqlCommand sqlcmd = new SqlCommand("sp_t_select_personel", baglanti);
            sqlcmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dr = new SqlDataAdapter(sqlcmd);
            DataSet ds = new DataSet();
            dr.Fill(ds);
            dataGridView2.DataSource = ds.Tables[0];
        }
        //Clear Data
        private void ClearData()
        {
            Ad.Text = "";
            Soyad.Text = "";
            SicilNo.Text = "";
            Tc.Text = "";
            Telefon.Text = "";
            Prim.Text = "";
            PersonelTipi.Text = "";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (SicilNo.Text.Length != 0 && Tc.Text.Length !=0 && Ad.Text.Length != 0 && Soyad.Text.Length != 0 && PersonelTipi.Text.Length != 0 && Telefon.Text.Length != 0 && Prim.Text.Length != 0 )
            {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=UrunSatis;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("InsertPersonel", con);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@SicilNo", SqlDbType.Int).Value = SicilNo.Text;
            cmd.Parameters.Add("@Tc", SqlDbType.NVarChar).Value = Tc.Text;
            cmd.Parameters.Add("@Ad", SqlDbType.NVarChar).Value = Ad.Text;
            cmd.Parameters.Add("@Soyad", SqlDbType.NVarChar).Value = Soyad.Text;
            cmd.Parameters.Add("@PersonelTipi", SqlDbType.Int).Value = PersonelTipi.Text;
            cmd.Parameters.Add("@Telefon", SqlDbType.NVarChar).Value = Telefon.Text;
            cmd.Parameters.Add("@Prim", SqlDbType.Decimal).Value = Prim.Text;
            cmd.ExecuteNonQuery();
            con.Close();
            DisplayData();
            ClearData();
            MessageBox.Show("Ekleme işlemi başarılı");
            }
            else
            {
                MessageBox.Show("Alanlar doldurulmalıdır.");
            }


        }

        private void button4_Click_1(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (SicilNo.Text.Length != 0 && Tc.Text.Length != 0 && Ad.Text.Length != 0 && Soyad.Text.Length != 0 && PersonelTipi.Text.Length != 0 && Telefon.Text.Length != 0 && Prim.Text.Length != 0)
            {
                SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=UrunSatis;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("UpdatePersonel", con);
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@SicilNo", SqlDbType.Int).Value = SicilNo.Text;
                cmd.Parameters.Add("@Tc", SqlDbType.NVarChar).Value = Tc.Text;
                cmd.Parameters.Add("@Ad", SqlDbType.NVarChar).Value = Ad.Text;
                cmd.Parameters.Add("@Soyad", SqlDbType.NVarChar).Value = Soyad.Text;
                cmd.Parameters.Add("@PersonelTipi", SqlDbType.Int).Value = PersonelTipi.Text;
                cmd.Parameters.Add("@Telefon", SqlDbType.NVarChar).Value = Telefon.Text;
                cmd.Parameters.Add("@Prim", SqlDbType.Decimal).Value = Prim.Text;
                cmd.ExecuteNonQuery();
                con.Close();
                DisplayData();
                ClearData();
                MessageBox.Show("Sicil No`ya göre Guncelleme işlemi başarılı");
            }
            else
            {
                MessageBox.Show("Alanlar doldurulmalıdır.");
            }
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (SicilNo.Text.Length != 0 && Tc.Text.Length != 0 && Ad.Text.Length != 0 && Soyad.Text.Length != 0 && PersonelTipi.Text.Length != 0 && Telefon.Text.Length != 0 && Prim.Text.Length != 0)
            {
                SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=UrunSatis;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("DeletePersonel", con);
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@SicilNo", SqlDbType.Int).Value = SicilNo.Text;
                cmd.ExecuteNonQuery();
                con.Close();
                DisplayData();
                ClearData();
                MessageBox.Show("Sicil No`ya göre silme işlemi başarılı");
            }
            else
            {
                MessageBox.Show("Alanlar doldurulmalıdır.");
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            SqlConnection baglanti = new SqlConnection("Data Source=.;Initial Catalog=UrunSatis;Integrated Security=True");
            SqlCommand sqlcmd = new SqlCommand("PersonelSayilariniGetir", baglanti);
            sqlcmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter dr = new SqlDataAdapter(sqlcmd);
            DataSet ds = new DataSet();
            dr.Fill(ds);
            dataGridView2.DataSource = ds.Tables[0];
        }

        private void Lobby_Load(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }
    }
}
