<?php 

function check($p1)
{	
	$deger = true;
	if(isset($p1))
	{
 	return $deger;
	}

}




 ?>