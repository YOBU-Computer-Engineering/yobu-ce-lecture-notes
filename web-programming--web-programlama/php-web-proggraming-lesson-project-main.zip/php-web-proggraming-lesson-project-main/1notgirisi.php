<?php
include_once "baglanti.php";


?>